package com.eventmanagement.faculty.facultymodel;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "faculty")
@Data
public class FacultyRegisterModel {
    @Id
    private String facultyId;
    private String facultyName;
    private String facultyEmailId;
    private String facultyPassword;
}
