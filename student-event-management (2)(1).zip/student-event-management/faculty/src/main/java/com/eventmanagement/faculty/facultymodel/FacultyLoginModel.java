package com.eventmanagement.faculty.facultymodel;

import lombok.Data;

@Data
public class FacultyLoginModel {
    private String facultyEmailId;
    private String facultyPassword;
}
