package com.eventmanagement.faculty.facultyservice;

import com.eventmanagement.faculty.security.JwtTokenUtil;
import com.eventmanagement.faculty.facultymodel.AuthResponse;
import com.eventmanagement.faculty.facultymodel.FacultyLoginModel;
import com.eventmanagement.faculty.facultymodel.FacultyRegisterModel;
import com.eventmanagement.faculty.facultyrepository.FacultyRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class FacultyLoginService {
    private final FacultyRepository fr;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenUtil jwtTokenUtil;

    public FacultyLoginService(FacultyRepository fr, PasswordEncoder passwordEncoder, JwtTokenUtil jwtTokenUtil) {
        this.fr = fr;
        this.passwordEncoder = passwordEncoder;
        this.jwtTokenUtil = jwtTokenUtil;
    }

    public AuthResponse loginFaculty(FacultyLoginModel loginModel) {
        FacultyRegisterModel faculty = fr.findByFacultyEmailId(loginModel.getFacultyEmailId());
        
        if (faculty != null && passwordEncoder.matches(loginModel.getFacultyPassword(), faculty.getFacultyPassword())) {
            String token = jwtTokenUtil.generateToken(faculty.getFacultyEmailId());
            return new AuthResponse(token, faculty);
        }
        return null;
    }
}
