package com.eventmanagement.faculty.facultyrepository;

import com.eventmanagement.faculty.facultymodel.FacultyRegisterModel;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FacultyRepository extends MongoRepository<FacultyRegisterModel, String> {
    FacultyRegisterModel findByFacultyEmailId(String facultyEmailId);
    FacultyRegisterModel findByFacultyEmailIdAndFacultyPassword(String facultyEmailId, String facultyPassword);
}
