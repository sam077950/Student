package com.eventmanagement.faculty.facultycontroller;

import com.eventmanagement.faculty.facultymodel.AuthResponse;
import com.eventmanagement.faculty.facultymodel.FacultyLoginModel;
import com.eventmanagement.faculty.facultymodel.FacultyRegisterModel;
import com.eventmanagement.faculty.facultyservice.FacultyLoginService;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/faculty")
public class FacultyLoginController {
    private final FacultyLoginService fls;

    public FacultyLoginController(FacultyLoginService fls) {
        this.fls = fls;
    }

    @PostMapping("/login")
    public AuthResponse login(@RequestBody FacultyLoginModel loginModel) {
        return fls.loginFaculty(loginModel);
    }
}
