package com.eventmanagement.faculty.facultyservice;

import com.eventmanagement.faculty.facultymodel.FacultyRegisterModel;
import com.eventmanagement.faculty.facultyrepository.FacultyRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class FacultyRegisterService {
    private final FacultyRepository fr;
    private final PasswordEncoder passwordEncoder;

    public FacultyRegisterService(FacultyRepository fr, PasswordEncoder passwordEncoder) {
        this.fr = fr;
        this.passwordEncoder = passwordEncoder;
    }

    public FacultyRegisterModel registerFaculty(FacultyRegisterModel faculty) {
        faculty.setFacultyPassword(passwordEncoder.encode(faculty.getFacultyPassword()));
        return fr.save(faculty);
    }
}
