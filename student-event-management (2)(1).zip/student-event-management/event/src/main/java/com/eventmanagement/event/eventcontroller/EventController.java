package com.eventmanagement.event.eventcontroller;

import com.eventmanagement.event.eventmodel.EventModel;
import com.eventmanagement.event.eventservice.EventService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/events")
public class EventController {
    private final EventService es;
    public EventController(EventService es) {
        this.es = es;
    }

    // Faculty: Add event
    @PostMapping("/")
    public EventModel postEvent(@RequestBody EventModel em) {
        return es.createEvent(em);
    }

    // Faculty: View all events
    @GetMapping("/")
    public List<EventModel> getAllEvents() {
        return es.displayAllEvents();
    }

    // Faculty/Student: View event by eventId
    @GetMapping("/{eventId}")
    public EventModel getEvent(@PathVariable String eventId) {
        return es.displayEvent(eventId);
    }

    // Student: View events by roll number
    @GetMapping("/student/{studentRollNo}")
    public List<EventModel> getEventsByStudent(@PathVariable String studentRollNo) {
        return es.displayEventsByStudent(studentRollNo);
    }

    // Faculty: View events by month (e.g. /events/month/2026-04 or /events/month/04)
    @GetMapping("/month/{month}")
    public List<EventModel> getEventsByMonth(@PathVariable String month) {
        return es.displayEventsByMonth(month);
    }

    // View pending events (Faculty only)
    @GetMapping("/pending")
    public List<EventModel> getPendingEvents() {
        return es.displayEventsByStatus("PENDING");
    }

    // Faculty: Approve/Reject event
    @PutMapping("/status/{eventId}")
    public EventModel updateStatus(@PathVariable String eventId, @RequestParam String status) {
        return es.updateEventStatus(eventId, status);
    }

    // Student: RSVP for event
    @PostMapping("/rsvp/{eventId}")
    public EventModel rsvpEvent(@PathVariable String eventId, @RequestParam String studentRollNo) {
        return es.rsvpEvent(eventId, studentRollNo);
    }

    // Faculty: Update event (only by faculty who created it)
    @PutMapping("/{eventId}")
    public EventModel putEvent(@PathVariable String eventId,
                               @RequestParam String organizerId,
                               @RequestBody EventModel inp) {
        return es.updateEvent(eventId, organizerId, inp);
    }

    // Faculty: Delete event (only by faculty who created it)
    @DeleteMapping("/{eventId}")
    public String deleteEvent(@PathVariable String eventId,
                              @RequestParam String organizerId) {
        return es.removeEvent(eventId, organizerId);
    }
}
