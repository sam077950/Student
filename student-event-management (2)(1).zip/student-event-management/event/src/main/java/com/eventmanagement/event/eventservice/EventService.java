package com.eventmanagement.event.eventservice;

import com.eventmanagement.event.eventmodel.EventModel;
import com.eventmanagement.event.eventrepository.EventRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventService {
    private final EventRepository er;
    public EventService(EventRepository er) {
        this.er = er;
    }

    public EventModel createEvent(EventModel em) {
        return er.save(em);
    }

    public List<EventModel> displayAllEvents() {
        return er.findByStatus("APPROVED");
    }

    public List<EventModel> displayEventsByStatus(String status) {
        return er.findByStatus(status);
    }

    public EventModel rsvpEvent(String eventId, String studentRollNo) {
        EventModel em = er.findByEventId(eventId);
        if (em == null) return null;
        if (em.getAttendees().size() < em.getCapacity() && !em.getAttendees().contains(studentRollNo)) {
            em.getAttendees().add(studentRollNo);
            return er.save(em);
        }
        return em;
    }

    public EventModel updateEventStatus(String eventId, String status) {
        EventModel em = er.findByEventId(eventId);
        if (em == null) return null;
        em.setStatus(status);
        return er.save(em);
    }

    public EventModel displayEvent(String eventId) {
        return er.findByEventId(eventId);
    }

    public List<EventModel> displayEventsByStudent(String studentRollNo) {
        // Find events where student is the organizer OR attendee
        return er.findByStudentRollNo(studentRollNo);
    }

    public List<EventModel> displayEventsByMonth(String month) {
        return er.findByEventDateContaining(month);
    }

    public EventModel updateEvent(String eventId, String organizerId, EventModel inp) {
        EventModel em = er.findByEventId(eventId);
        if (em == null) return null;
        // Access control: only the organizer can update
        if (em.getOrganizerId() != null && !em.getOrganizerId().equals(organizerId)) return null;
        
        em.setEventName(inp.getEventName());
        em.setEventLocation(inp.getEventLocation());
        em.setEventDate(inp.getEventDate());
        em.setEventDescription(inp.getEventDescription());
        em.setTags(inp.getTags());
        em.setCapacity(inp.getCapacity());
        return er.save(em);
    }

    public String removeEvent(String eventId, String organizerId) {
        EventModel em = er.findByEventId(eventId);
        if (em == null) return "Event not found!";
        if (em.getOrganizerId() != null && !em.getOrganizerId().equals(organizerId)) 
            return "Access denied! You can only delete your own event records.";
        er.deleteByEventId(eventId);
        return "Event with id: " + eventId + " is deleted!";
    }
}
