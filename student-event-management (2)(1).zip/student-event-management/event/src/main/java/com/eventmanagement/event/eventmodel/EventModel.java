package com.eventmanagement.event.eventmodel;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.ArrayList;
import java.util.List;

@Document(collection="events")
@Data
public class EventModel {
    @Id
    private String eventId;
    private String eventName;
    private String eventLocation;
    private String eventDate;
    private String eventDescription;
    
    // Advanced Features
    private String status = "APPROVED"; // PENDING, APPROVED, REJECTED
    private String type = "FACULTY";    // STUDENT, FACULTY
    private List<String> tags = new ArrayList<>();
    private int capacity = 100;
    private List<String> attendees = new ArrayList<>();
    
    // Identification
    private String organizerId;         // Can be studentRollNo or facultyId
    private String studentName;         // Keep for legacy compatibility
    private String studentRollNo;       // Keep for legacy compatibility
    private String facultyId;           // Keep for legacy compatibility
}
