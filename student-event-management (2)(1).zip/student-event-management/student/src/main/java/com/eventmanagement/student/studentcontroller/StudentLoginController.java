package com.eventmanagement.student.studentcontroller;

import com.eventmanagement.student.studentmodel.AuthResponse;
import com.eventmanagement.student.studentmodel.StudentLoginModel;
import com.eventmanagement.student.studentmodel.StudentRegisterModel;
import com.eventmanagement.student.studentservice.StudentLoginService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/student")
public class StudentLoginController {
    private final StudentLoginService sls;

    public StudentLoginController(StudentLoginService sls) {
        this.sls = sls;
    }

    @PostMapping("/login")
    public AuthResponse login(@RequestBody StudentLoginModel loginModel) {
        return sls.loginStudent(loginModel);
    }

    // Uses RestTemplate to call Event Service on port 8081 and return real event data
    @GetMapping("/events/{studentRollNo}")
    public List<EventModel> getEventsByRollNo(@PathVariable String studentRollNo) {
        return sls.getStudentEvents(studentRollNo);
    }
}
