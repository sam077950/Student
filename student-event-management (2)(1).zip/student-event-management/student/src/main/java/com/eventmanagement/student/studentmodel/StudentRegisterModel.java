package com.eventmanagement.student.studentmodel;

import lombok.Data;
import org.springframework.data.annotation.Id;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "students")
@Data
public class StudentRegisterModel {
    @Id
    private String studentRollNo;
    private String studentName;
    private String studentEmailId;
    private String studentPassword;
    
    // Advanced Features
    private List<String> interests = new ArrayList<>();
    private int points = 0;
}
