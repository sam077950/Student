package com.eventmanagement.student.studentservice;

import com.eventmanagement.student.studentmodel.StudentRegisterModel;
import com.eventmanagement.student.studentrepository.StudentRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class StudentRegisterService {
    private final StudentRepository sr;
    private final PasswordEncoder passwordEncoder;

    public StudentRegisterService(StudentRepository sr, PasswordEncoder passwordEncoder) {
        this.sr = sr;
        this.passwordEncoder = passwordEncoder;
    }

    public StudentRegisterModel registerStudent(StudentRegisterModel student) {
        student.setStudentPassword(passwordEncoder.encode(student.getStudentPassword()));
        return sr.save(student);
    }
}
