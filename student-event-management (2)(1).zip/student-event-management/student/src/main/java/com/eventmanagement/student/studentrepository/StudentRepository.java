package com.eventmanagement.student.studentrepository;

import com.eventmanagement.student.studentmodel.StudentRegisterModel;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentRepository extends MongoRepository<StudentRegisterModel, String> {
    StudentRegisterModel findByStudentEmailId(String studentEmailId);
    StudentRegisterModel findByStudentEmailIdAndStudentPassword(String studentEmailId, String studentPassword);
}
