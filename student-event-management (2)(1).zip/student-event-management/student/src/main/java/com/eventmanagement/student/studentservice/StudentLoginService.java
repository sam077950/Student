package com.eventmanagement.student.studentservice;

import com.eventmanagement.event.eventmodel.EventModel;
import com.eventmanagement.student.security.JwtTokenUtil;
import com.eventmanagement.student.studentmodel.AuthResponse;
import com.eventmanagement.student.studentmodel.StudentLoginModel;
import com.eventmanagement.student.studentmodel.StudentRegisterModel;
import com.eventmanagement.student.studentrepository.StudentRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service
public class StudentLoginService {
    private final StudentRepository sr;
    private final RestTemplate rt;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenUtil jwtTokenUtil;
    private final String eventServiceUrl;

    public StudentLoginService(StudentRepository sr, RestTemplate rt, 
                               PasswordEncoder passwordEncoder, JwtTokenUtil jwtTokenUtil,
                               @Value("${event.service.url:http://localhost:8081}") String eventServiceUrl) {
        this.sr = sr;
        this.rt = rt;
        this.passwordEncoder = passwordEncoder;
        this.jwtTokenUtil = jwtTokenUtil;
        this.eventServiceUrl = eventServiceUrl;
    }

    public AuthResponse loginStudent(StudentLoginModel loginModel) {
        StudentRegisterModel student = sr.findByStudentEmailId(loginModel.getStudentEmailId());
        
        if (student != null && passwordEncoder.matches(loginModel.getStudentPassword(), student.getStudentPassword())) {
            String token = jwtTokenUtil.generateToken(student.getStudentEmailId());
            return new AuthResponse(token, student);
        }
        return null; // Or throw custom exception
    }

    public List<EventModel> getStudentEvents(String studentRollNo) {
        String url = eventServiceUrl + "/events/student/" + studentRollNo;
        ResponseEntity<EventModel[]> response = rt.getForEntity(url, EventModel[].class);
        if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
            return Arrays.asList(response.getBody());
        }
        return Collections.emptyList();
    }
}
