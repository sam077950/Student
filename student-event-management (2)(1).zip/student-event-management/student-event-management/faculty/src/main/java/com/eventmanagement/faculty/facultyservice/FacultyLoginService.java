package com.eventmanagement.faculty.facultyservice;

import com.eventmanagement.faculty.facultymodel.FacultyLoginModel;
import com.eventmanagement.faculty.facultymodel.FacultyRegisterModel;
import com.eventmanagement.faculty.facultyrepository.FacultyRepository;
import org.springframework.stereotype.Service;

@Service
public class FacultyLoginService {
    private final FacultyRepository fr;
    public FacultyLoginService(FacultyRepository fr) {
        this.fr = fr;
    }
    public String loginFaculty(FacultyLoginModel loginModel) {
        FacultyRegisterModel faculty = fr.findByFacultyEmailIdAndFacultyPassword(
                loginModel.getFacultyEmailId(), loginModel.getFacultyPassword());
        if (faculty != null) {
            return "Login successful! Welcome, " + faculty.getFacultyName() + ". Your Faculty ID is: " + faculty.getFacultyId();
        }
        return "Invalid email or password!";
    }
}
