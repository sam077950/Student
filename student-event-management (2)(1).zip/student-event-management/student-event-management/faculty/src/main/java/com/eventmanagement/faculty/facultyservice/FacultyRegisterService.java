package com.eventmanagement.faculty.facultyservice;

import com.eventmanagement.faculty.facultymodel.FacultyRegisterModel;
import com.eventmanagement.faculty.facultyrepository.FacultyRepository;
import org.springframework.stereotype.Service;

@Service
public class FacultyRegisterService {
    private final FacultyRepository fr;
    public FacultyRegisterService(FacultyRepository fr) {
        this.fr = fr;
    }
    public FacultyRegisterModel registerFaculty(FacultyRegisterModel faculty) {
        return fr.save(faculty);
    }
}
