package com.eventmanagement.faculty.facultycontroller;

import com.eventmanagement.faculty.facultymodel.FacultyRegisterModel;
import com.eventmanagement.faculty.facultyservice.FacultyRegisterService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/faculty")
public class FacultyRegisterController {
    private final FacultyRegisterService frs;
    public FacultyRegisterController(FacultyRegisterService frs) {
        this.frs = frs;
    }
    @PostMapping("/register")
    public FacultyRegisterModel register(@RequestBody FacultyRegisterModel faculty) {
        return frs.registerFaculty(faculty);
    }
}
