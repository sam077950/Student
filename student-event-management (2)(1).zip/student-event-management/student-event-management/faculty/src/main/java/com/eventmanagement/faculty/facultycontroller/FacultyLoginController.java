package com.eventmanagement.faculty.facultycontroller;

import com.eventmanagement.faculty.facultymodel.FacultyLoginModel;
import com.eventmanagement.faculty.facultyservice.FacultyLoginService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/faculty")
public class FacultyLoginController {
    private final FacultyLoginService fls;
    public FacultyLoginController(FacultyLoginService fls) {
        this.fls = fls;
    }
    @PostMapping("/login")
    public String login(@RequestBody FacultyLoginModel loginModel) {
        return fls.loginFaculty(loginModel);
    }
}
