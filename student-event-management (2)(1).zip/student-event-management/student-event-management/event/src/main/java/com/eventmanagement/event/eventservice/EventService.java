package com.eventmanagement.event.eventservice;

import com.eventmanagement.event.eventmodel.EventModel;
import com.eventmanagement.event.eventrepository.EventRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventService {
    private final EventRepository er;
    public EventService(EventRepository er) {
        this.er = er;
    }

    public EventModel createEvent(EventModel em) {
        return er.save(em);
    }

    public List<EventModel> displayAllEvents() {
        return er.findAll();
    }

    public EventModel displayEvent(String eventId) {
        return er.findByEventId(eventId);
    }

    public List<EventModel> displayEventsByStudent(String studentRollNo) {
        return er.findByStudentRollNo(studentRollNo);
    }

    // View events by month — eventDate format: YYYY-MM-DD, month format: "04" or "2026-04"
    public List<EventModel> displayEventsByMonth(String month) {
        return er.findByEventDateContaining(month);
    }

    public EventModel updateEvent(String eventId, String facultyId, EventModel inp) {
        EventModel em = er.findByEventId(eventId);
        if (em == null) return null;
        // Access control: only the faculty who created the event can update it
        if (!em.getFacultyId().equals(facultyId)) return null;
        em.setStudentName(inp.getStudentName());
        em.setStudentRollNo(inp.getStudentRollNo());
        em.setEventName(inp.getEventName());
        em.setEventLocation(inp.getEventLocation());
        em.setEventDate(inp.getEventDate());
        em.setEventDescription(inp.getEventDescription());
        return er.save(em);
    }

    public String removeEvent(String eventId, String facultyId) {
        EventModel em = er.findByEventId(eventId);
        if (em == null) return "Event not found!";
        // Access control: only the faculty who created the event can delete it
        if (!em.getFacultyId().equals(facultyId)) return "Access denied! You can only delete your own event records.";
        er.deleteByEventId(eventId);
        return "Event with id: " + eventId + " is deleted!";
    }
}
