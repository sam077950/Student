package com.eventmanagement.event.eventmodel;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="events")
@Data

public class EventModel {
    @Id
    private String eventId;
    private String studentName;
    private String studentRollNo;
    private String eventName;
    private String eventLocation;
    private String eventDate;
    private String eventDescription;
    private String facultyId;
}
