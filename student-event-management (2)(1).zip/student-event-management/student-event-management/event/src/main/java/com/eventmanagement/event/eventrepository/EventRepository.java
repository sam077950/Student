package com.eventmanagement.event.eventrepository;

import com.eventmanagement.event.eventmodel.EventModel;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EventRepository extends MongoRepository<EventModel, String> {
    EventModel findByEventId(String eventId);
    void deleteByEventId(String eventId);
    List<EventModel> findByStudentRollNo(String studentRollNo);
    List<EventModel> findByEventDateContaining(String month);
    List<EventModel> findByFacultyId(String facultyId);
}
