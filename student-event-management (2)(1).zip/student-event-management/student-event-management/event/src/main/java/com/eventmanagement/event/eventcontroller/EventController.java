package com.eventmanagement.event.eventcontroller;

import com.eventmanagement.event.eventmodel.EventModel;
import com.eventmanagement.event.eventservice.EventService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/events")
public class EventController {
    private final EventService es;
    public EventController(EventService es) {
        this.es = es;
    }

    // Faculty: Add event
    @PostMapping("/")
    public EventModel postEvent(@RequestBody EventModel em) {
        return es.createEvent(em);
    }

    // Faculty: View all events
    @GetMapping("/")
    public List<EventModel> getAllEvents() {
        return es.displayAllEvents();
    }

    // Faculty/Student: View event by eventId
    @GetMapping("/{eventId}")
    public EventModel getEvent(@PathVariable String eventId) {
        return es.displayEvent(eventId);
    }

    // Student: View events by roll number
    @GetMapping("/student/{studentRollNo}")
    public List<EventModel> getEventsByStudent(@PathVariable String studentRollNo) {
        return es.displayEventsByStudent(studentRollNo);
    }

    // Faculty: View events by month (e.g. /events/month/2026-04 or /events/month/04)
    @GetMapping("/month/{month}")
    public List<EventModel> getEventsByMonth(@PathVariable String month) {
        return es.displayEventsByMonth(month);
    }

    // Faculty: Update event (only by faculty who created it)
    // Pass facultyId as request param: PUT /events/EVT001?facultyId=F001
    @PutMapping("/{eventId}")
    public EventModel putEvent(@PathVariable String eventId,
                               @RequestParam String facultyId,
                               @RequestBody EventModel inp) {
        EventModel result = es.updateEvent(eventId, facultyId, inp);
        return result;
    }

    // Faculty: Delete event (only by faculty who created it)
    // Pass facultyId as request param: DELETE /events/EVT001?facultyId=F001
    @DeleteMapping("/{eventId}")
    public String deleteEvent(@PathVariable String eventId,
                              @RequestParam String facultyId) {
        return es.removeEvent(eventId, facultyId);
    }
}
