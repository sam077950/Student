package com.eventmanagement.student.studentmodel;

import lombok.Data;

@Data
public class StudentLoginModel {
    private String studentEmailId;
    private String studentPassword;
}
