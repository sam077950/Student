package com.eventmanagement.student.studentservice;

import com.eventmanagement.event.eventmodel.EventModel;
import com.eventmanagement.student.studentmodel.StudentLoginModel;
import com.eventmanagement.student.studentmodel.StudentRegisterModel;
import com.eventmanagement.student.studentrepository.StudentRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service
public class StudentLoginService {
    private final StudentRepository sr;
    private final RestTemplate rt;

    public StudentLoginService(StudentRepository sr, RestTemplate rt) {
        this.sr = sr;
        this.rt = rt;
    }

    public String loginStudent(StudentLoginModel loginModel) {
        StudentRegisterModel student = sr.findByStudentEmailIdAndStudentPassword(
                loginModel.getStudentEmailId(), loginModel.getStudentPassword());
        if (student != null) {
            return "Login successful! Welcome, " + student.getStudentName()
                    + ". Your Roll Number is: " + student.getStudentRollNo();
        }
        return "Invalid email or password!";
    }

    public List<EventModel> getStudentEvents(String studentRollNo) {
        String url = "http://localhost:8081/events/student/" + studentRollNo;
        ResponseEntity<EventModel[]> response = rt.getForEntity(url, EventModel[].class);
        if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
            return Arrays.asList(response.getBody());
        }
        return Collections.emptyList();
    }
}
