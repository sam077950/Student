package com.eventmanagement.student.studentmodel;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "students")
@Data
public class StudentRegisterModel {
    @Id
    private String studentRollNo;
    private String studentName;
    private String studentEmailId;
    private String studentPassword;
}
