package com.eventmanagement.student.studentcontroller;

import com.eventmanagement.event.eventmodel.EventModel;
import com.eventmanagement.student.studentmodel.StudentLoginModel;
import com.eventmanagement.student.studentservice.StudentLoginService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentLoginController {
    private final StudentLoginService sls;

    public StudentLoginController(StudentLoginService sls) {
        this.sls = sls;
    }

    @PostMapping("/login")
    public String login(@RequestBody StudentLoginModel loginModel) {
        return sls.loginStudent(loginModel);
    }

    // Uses RestTemplate to call Event Service on port 8081 and return real event data
    @GetMapping("/events/{studentRollNo}")
    public List<EventModel> getEventsByRollNo(@PathVariable String studentRollNo) {
        return sls.getStudentEvents(studentRollNo);
    }
}
