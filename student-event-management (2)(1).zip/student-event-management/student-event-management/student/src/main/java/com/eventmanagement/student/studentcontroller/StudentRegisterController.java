package com.eventmanagement.student.studentcontroller;

import com.eventmanagement.student.studentmodel.StudentRegisterModel;
import com.eventmanagement.student.studentservice.StudentRegisterService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/student")
public class StudentRegisterController {
    private final StudentRegisterService rs;
    public StudentRegisterController(StudentRegisterService rs) {
        this.rs = rs;
    }
    @PostMapping("/register")
    public StudentRegisterModel register(@RequestBody StudentRegisterModel student) {
        return rs.registerStudent(student);
    }
}
