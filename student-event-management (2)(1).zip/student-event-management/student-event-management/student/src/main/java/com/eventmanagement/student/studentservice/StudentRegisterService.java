package com.eventmanagement.student.studentservice;

import com.eventmanagement.student.studentmodel.StudentRegisterModel;
import com.eventmanagement.student.studentrepository.StudentRepository;
import org.springframework.stereotype.Service;

@Service
public class StudentRegisterService {
    private final StudentRepository sr;
    public StudentRegisterService(StudentRepository sr) {
        this.sr = sr;
    }
    public StudentRegisterModel registerStudent(StudentRegisterModel student) {
        return sr.save(student);
    }
}
